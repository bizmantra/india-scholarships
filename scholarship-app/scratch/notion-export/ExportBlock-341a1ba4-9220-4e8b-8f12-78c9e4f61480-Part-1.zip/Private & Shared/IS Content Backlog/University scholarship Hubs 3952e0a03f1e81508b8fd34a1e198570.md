# University scholarship Hubs

ID: CNT-2
Status: ✅ Done