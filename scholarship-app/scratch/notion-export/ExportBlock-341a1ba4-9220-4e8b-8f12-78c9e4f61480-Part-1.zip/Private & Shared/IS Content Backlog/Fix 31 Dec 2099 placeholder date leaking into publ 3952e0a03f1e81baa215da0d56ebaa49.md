# Fix "31 Dec 2099" placeholder date leaking into public deadline field (Odisha)

ID: CNT-15
Impact: High
Status: ✅ Done

## Issue

Six scholarship cards on the Odisha state hub page ([https://www.indiascholarships.in/scholarships-in/odisha](https://www.indiascholarships.in/scholarships-in/odisha)) display "31 Dec 2099" as the deadline.

## Affected scholarships

- e-Medhabruti UG Merit Scholarship
- e-Medhabruti PG Merit Scholarship
- e-Medhabruti Technical/Professional Scholarship
- Green Passage Scheme (Higher Education)
- Green Passage Scheme (Technical)
- Sudakshya for Girls Child Scholarship

## Why it matters

"31 Dec 2099" is not a real deadline — it looks like an internal placeholder/sentinel value (likely meaning "no fixed deadline" or "rolling admission") that's leaking directly into the public UI instead of being displayed as "Rolling", "No Fixed Deadline", or "Check Portal." The site already uses "Check Portal" correctly elsewhere on the same page (e.g. Junior Merit Scholarship), so the fallback pattern exists — it's just not being applied consistently.

A student seeing "Deadline: 31 Dec 2099" is likely to assume the page is broken or the data is fake, which undermines trust more than a missing deadline would.

## Suggested fix

Find whatever logic assigns a deadline value when none is set, and confirm it should be defaulting to a display string ("Rolling" / "Check Portal") rather than a hardcoded far-future date like 2099-12-31. This is likely a shared component/pipeline issue, not specific to these 6 scholarships — worth checking whether other states have the same placeholder leaking through.

## Scope

Only confirmed on Odisha so far. Separate issue from the leaked-verification-notes bug (Karnataka) and the missing-expired-badge bug — three distinct, independently fixable problems that happened to surface during the same review.