# Research & scope International High-Value Scholarships (study-abroad content track)

Description: GOAL: Explore a new content track — international/study-abroad scholarships for Indian students — as a Phase 2 expansion beyond the 251 domestic scholarships. Use Antigravity to continue research + population once scoped.

CANDIDATE LIST (from initial research):
- Fulbright-Nehru (USA) — $35-45K/yr, fully funded
- Chevening (UK) — £50K+, ~8-10% acceptance for Indians
- DAAD (Germany) — €992-1200/mo, free public-uni tuition
- Erasmus Mundus (EU) — ~€1000-1400/mo, no central portal (fragmented by consortium)
- Commonwealth Master's (UK) — fully funded, <1% acceptance
- Inlaks Shivdasani — up to $100K, excludes most engineering/CS
- JN Tata Endowment — loan up to ₹20L, repayable 7 yrs
- Rhodes / Gates Cambridge (UK) — fully funded, very low volume
- MEXT (Japan) — fully funded, less saturated content space

KEY FINDINGS / CAUTIONS FROM SCOPING DISCUSSION:
1. RPM logic check: RPM is driven by visitor geography at click time, not topic — writing about study-abroad scholarships does NOT automatically raise RPM since readers are still browsing from India. Real RPM lever is content adjacency to high-CPC verticals (education loans, forex cards, IELTS/GRE prep, visa/consultancy services) — build these as connective content around scholarship pages, not instead of them.
2. Competitive reality: Buddy4Study, LeapScholar, upGrad, GyanDhan, Leverage Edu already dominate SERPs for every major international scholarship name (Chevening, Fulbright-Nehru, DAAD, etc.) with much larger DA/backlink profiles. Standalone "[Scholarship] eligibility" pages are a weak differentiation play here — our 29-field/verified-decision-engine moat doesn't transfer topical authority from domestic to this new lane (Google evaluates by topical cluster, not domain-wide).
3. Keyword reality: no meaningful search volume exists for a generic "international scholarship tracker" query. Real demand pattern is per-scholarship: "[Scholarship Name] + last date to apply / eligibility / 2026-27" — same modifier pattern already proven on our domestic deadline tracker (live: http://indiascholarships.in/scholarships/deadlines) and used site-wide by Buddy4Study.
4. Where a genuine opening exists: a live, verified "which international scholarships are open right now" status page — nobody maintains this well for the international set (smaller competitor DesiUtils does something similar). This plays directly to our verification-first positioning and reuses the same deadline-tracker pattern we just shipped domestically.
5. Natural bridge asset already in DB: Odisha's Videsh Siksha Bruti (up to ₹25L for SC/ST students going abroad) — cross-link candidate between domestic and international content once this track exists.

SCHEMA NOTE: international scholarships need their own lighter data structure vs. the 29-field domestic template — currency conversion, cycle-based (not fixed annual) deadlines, no income/caste eligibility fields, consortium-level fragmentation (e.g. Erasmus Mundus has no single portal).

NEXT STEPS: scope with Antigravity — pilot with a small subset (5-8 scholarships) styled as a status tracker + individual pages only where a genuinely differentiated angle exists (e.g. MEXT, Erasmus Mundus fragmentation), rather than competing head-on on saturated terms like Chevening/Fulbright.
ID: CNT-14
Status: ✅ Done