# BHU & AMU Hubs & Research

Description: Research official internal schemes and build scholarship hubs for Banaras Hindu University (BHU) and Aligarh Muslim University (AMU).
ID: CNT-7
Status: ✅ Done