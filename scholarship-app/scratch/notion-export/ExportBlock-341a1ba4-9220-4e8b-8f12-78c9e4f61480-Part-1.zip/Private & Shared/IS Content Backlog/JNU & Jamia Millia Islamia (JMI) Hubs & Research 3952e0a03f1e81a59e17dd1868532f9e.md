# JNU & Jamia Millia Islamia (JMI) Hubs & Research

Description: Research official internal schemes and build scholarship hubs for Jawaharlal Nehru University (JNU) and Jamia Millia Islamia (JMI).
ID: CNT-8
Status: ✅ Done