# SPPU (Pune) & AKTU (UP) Hubs & Research

Description: Research official internal schemes and build scholarship hubs for Savitribai Phule Pune University (SPPU) and Dr. A.P.J. Abdul Kalam Technical University (AKTU, UP).
ID: CNT-11
Status: ✅ Done

## Verified Scholarship Schemes Research Summary

### 1. Savitribai Phule Pune University (SPPU)

- **Scheme Name:** SPPU Karmaveer Bhaurao Patil Earn & Learn Scheme (sppu-earn-and-learn-scheme)
- **Eligibility:** Regular students of SPPU/affiliated colleges, family income < ₹2,00,000/year, minimum 50% marks.
- **Benefits:** Monthly wages based on hourly campus work (max 3 hrs/day), earning up to ₹40,000/year.
- **Official Source:** http://www.unipune.ac.in (Helpline: +91-20-25621111)

### 2. Dr. A.P.J. Abdul Kalam Technical University (AKTU)

- **Scheme Name:** AKTU Student Welfare Fund & Fee Reimbursement Scheme (aktu-student-welfare-fund-assistance)
- **Eligibility:** UP residents, AKTU-affiliated college students, family income < ₹2.5L (SC/ST) or ₹2L (OBC/Gen/Minority).
- **Benefits:** UP state fee reimbursement up to ₹50,000/year + emergency financial support.
- **Official Source:** https://aktu.ac.in (UP Scholarship Portal: scholarship.up.gov.in)

*✅ Verification: Checked against data/scholarships.db and content quality audit report (0 issues). Live synced to website.*