# Anna University & VTU Hubs & Research

Description: Research official internal schemes and build scholarship hubs for Anna University (TN) and Visvesvaraya Technological University (VTU, Karnataka).
ID: CNT-10
Status: ✅ Done