# State hub QA: leaked verification notes + expired deadlines on Karnataka page (likely site-wide pattern)

ID: CNT-17
Impact: Critical
Status: 🔴 Now

## Source

Direct fetch of the live page ([https://www.indiascholarships.in/scholarships-in/karnataka](https://www.indiascholarships.in/scholarships-in/karnataka)), July 6 2026, cross-checked against the screenshot shared in chat. Karnataka was picked as the "flagship/best example" state hub, which makes these findings more concerning, not less — if the best page has this, others likely do too.

## Critical Issue 1: Internal verification notes leaking into public deadline fields

Several scholarship cards show raw editorial/research notes instead of clean copy, e.g.:

- "September 30, 2025 (tentative - some sources indicate November 30, 2025 or extended deadlines). VERIFY on official NSP and SSP portals for exact date."
- "November 30, 2025 (most departments). Brahmin Development Board: October 2025 (tentative). AYUSH Department: February 28, 2026. Verify specific deadline based on sub-category."
- "February 28, 2026 (AYUSH/Arya Vysha depts). October 2025 (tentative for main scheme). VERIFY current deadline on portal."

This directly contradicts the "100% Data Freshness — Verified Jan 2026" trust badge displayed at the top of the same page. Reads as unfinished/unprofessional to any visitor. Needs a pre-publish QA step that catches "VERIFY", "tentative", "some sources indicate" style language before it goes live — either resolve to a single clean date or use the site's existing "Check Official Portal" pattern consistently.

## Critical Issue 2: Expired deadlines live on the page (fetched July 6, 2026)

- Pre-Matric ST Students: 7 Mar 2025 (expired)
- Merit-Cum-Means Scholarship (Minorities): 30 Sept 2025 (expired)
- Pre-Matric OBC: 31 Oct 2025 (expired)
- Pre-Matric Minorities: 30 Nov 2025 (expired)
- NMMS: 15 Oct 2025 (expired)

Same root issue Atlas already flags site-wide (127 expired deadlines). This is a concrete, visible instance of it on the page being used as the "done well" example state.

## Medium: Likely duplicate scheme entries

"SSP Pre-Matric & Post-Matric Scholarship (Karnataka)" and "Pre-Matric & Post-Matric Scholarships (SSP)" appear to be the same underlying scheme listed as two separate cards — one fully enriched (₹1,000-₹1,00,000, clean 15 Jan 2026 deadline), one thin ("Amount varies...Check Portal"). Recommend merging into one canonical entry rather than splitting clicks/authority.

## Low: Data source discrepancy — needs a sync check, not a fix

Live Karnataka hub page states "26 verified opportunities." The working inventory export used throughout this week's analysis (scholarships_inventory.xlsx, pulled July 5) showed only 19 for Karnataka. Either the site has moved ahead of the export, or there's a counting/tagging mismatch. Worth reconciling — may mean the existing "14 missing Karnataka scholarships" backlog task is partly or fully resolved already.

## Also worth considering (UX, lower priority)

- No category filter (SC/ST/OBC/Minority/General/PWD) on a 26-card flat list — friction on mobile (82% of site traffic)
- Card order appears arbitrary rather than sorted by deadline urgency or category traffic volume
- "Max Amount ₹30,00,000" headline stat is a rare PG/overseas scholarship, not representative of the typical ₹3,000-₹60,000 range — could read as bait; consider labeling more precisely or adding a "Typical Range" stat alongside it

## Next step

Apply this same review to other state hub pages — starting with the highest-traffic ones (Odisha, West Bengal, Maharashtra, Tamil Nadu, Madhya Pradesh) since a systemic QA gap (not a one-off Karnataka issue) is the likely explanation given Karnataka was the best-case example.

[](State%20hub%20QA%20leaked%20verification%20notes%20+%20expired%20d/Untitled%203952e0a03f1e81608f1dce59cab95000.md)

[](State%20hub%20QA%20leaked%20verification%20notes%20+%20expired%20d/Untitled%203952e0a03f1e81aeaa32d0978a1786b8.md)

[](State%20hub%20QA%20leaked%20verification%20notes%20+%20expired%20d/Untitled%203952e0a03f1e81189197c207b4ecc401.md)