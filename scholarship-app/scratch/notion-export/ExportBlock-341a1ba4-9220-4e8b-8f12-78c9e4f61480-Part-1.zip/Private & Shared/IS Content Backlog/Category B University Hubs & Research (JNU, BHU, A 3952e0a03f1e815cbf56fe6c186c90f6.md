# Category B University Hubs & Research (JNU, BHU, AMU, JMI, UoH)

Description: Research official internal schemes and build scholarship hubs for JNU, BHU, AMU, JMI, and Hyderabad University (UoH).
ID: CNT-5
Status: ✅ Done