# Fix leaked internal verification notes appearing in public deadline fields (Karnataka)

ID: CNT-16
Impact: High
Status: ✅ Done

## Issue

Several scholarship cards on the Karnataka state hub page ([https://www.indiascholarships.in/scholarships-in/karnataka](https://www.indiascholarships.in/scholarships-in/karnataka)) show raw internal research/editorial notes directly in the public-facing deadline field, instead of a clean date or the site's existing "Check Official Portal" fallback.

## Examples found (July 6, 2026)

- "September 30, 2025 (tentative - some sources indicate November 30, 2025 or extended deadlines). VERIFY on official NSP and SSP portals for exact date."
- "November 30, 2025 (most departments). Brahmin Development Board: October 2025 (tentative). AYUSH Department: February 28, 2026. Verify specific deadline based on sub-category."
- "February 28, 2026 (AYUSH/Arya Vysha depts). October 2025 (tentative for main scheme). VERIFY current deadline on portal."

## Why it matters

This directly contradicts the "100% Data Freshness — Verified Jan 2026" trust badge shown at the top of the same page. Reads as unfinished/unprofessional — a visitor sees text that looks like a note-to-self ("verify this") rather than information meant for them.

## Suggested fix

Add a pre-publish check (manual or automated) that flags any deadline field containing words like "VERIFY", "tentative", "some sources indicate" before it goes live. Each of these should resolve to either a single clean date, or the existing "Check Official Portal" pattern already used correctly elsewhere on the same page.

## Scope

Only directly confirmed on Karnataka so far. Worth a quick check on a few other state pages to see if it's isolated to Karnataka's enrichment batch or a wider pattern — separate from the "expired deadline badge not rendering" issue, which is a different, display-logic bug.