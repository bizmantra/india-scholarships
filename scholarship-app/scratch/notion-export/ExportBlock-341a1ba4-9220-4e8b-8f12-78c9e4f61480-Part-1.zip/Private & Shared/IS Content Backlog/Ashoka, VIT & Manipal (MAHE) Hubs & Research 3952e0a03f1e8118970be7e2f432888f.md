# Ashoka, VIT & Manipal (MAHE) Hubs & Research

Description: Research official internal schemes and build scholarship hubs for Ashoka University, Vellore Institute of Technology (VIT), and Manipal Academy of Higher Education (MAHE).
ID: CNT-12
Status: ✅ Done

## Verified Scholarship Schemes Research Summary

### 1. Ashoka University

- **Need-Based Financial Aid:** Waivers of 25% to 100% of all tuition, residence, and meals (up to ₹11,00,000/year).
- **Merit-Based Scholarships:** 100% tuition waivers for top rankers in national tests (JEE >98th percentile, IAT top 2000) and board exam toppers (>98%).
- **Young India Fellowship (YIF):** PG Leadership fellowship offering 25% to 100% need-based tuition/boarding waivers + Chancellor's Merit Scholarships.

### 2. Vellore Institute of Technology (VIT)

- **VIT STARS Scheme:** 100% academic/hostel/mess waivers (₹4,50,000/year) + free laptop for rural government school toppers in TN/AP/MP.
- **GVSDP Merit Scholarship:** Tuition waivers from 25% to 100% (up to ₹4,50,000/year) based on VITEEE rank.

### 3. Manipal Academy of Higher Education (MAHE)

- **Kalam-Pai Freeships & Scholars Scholarships:** 100% freeships (B.Tech/MBBS up to ₹5,00,000/year) for top MET/NEET rankers, family income < ₹12L.

*✅ Verification: Checked against database, resolved quality issues on YIF, updated keywords for Ashoka/VIT, and completed live WordPress sync.*