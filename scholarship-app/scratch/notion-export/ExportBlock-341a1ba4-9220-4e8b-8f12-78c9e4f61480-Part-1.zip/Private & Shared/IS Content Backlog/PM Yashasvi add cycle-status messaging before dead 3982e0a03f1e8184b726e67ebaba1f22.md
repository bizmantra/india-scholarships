# PM Yashasvi: add cycle-status messaging before deadline hits (traffic protection)

ID: CNT-18
Impact: Critical
Status: 🔴 Now

**Why now:** PM Yashasvi deadline ends end of July 2026. It's ~38-40% of total site clicks. GSC data shows "last date" query volume stays active even after a deadline passes — without status messaging, those searchers bounce back to Google, which quietly hurts rankings over time even while impressions hold.

**What to add to the live page before end of month:**

1. Banner/callout below H1: "2025-26 cycle closed [DATE] — 2026-27 typically opens [MONTH]" — verify real dates against NSP/PM YASASVI portal first, do not guess (critical field per zero-hallucination policy)
2. Email capture / "notify me when applications reopen" — ties into the 500+/month subscriber target in Atlas (currently at 0)
3. FAQ additions: "Is it still open?", "What if I missed the deadline?", "How do I know when it reopens?"
4. Update meta description to reflect cycle status (helps CTR on still-active "last date" queries)
5. Add "last updated" date near the banner, refresh when confirmed

**Bonus (traffic redistribution):** while PM Yashasvi still has traffic, internal-link from it to Nabanna and Kanya Utthan ("other scholarships closing soon") — both are already showing early anchor-page behavior per GSC deep-dive and are the best candidates to absorb PM Yashasvi's post-deadline traffic share. Ties to existing Atlas target: PM Yashasvi % of clicks 40% → <20% by Sep 2026.

Draft copy (2 options, needs date verification before publishing): see chat output `pm-yashasvi-cycle-status-copy.md` from July 9 2026 session.

**Source:** July 9 2026 Claude session — traffic concentration risk discussion.