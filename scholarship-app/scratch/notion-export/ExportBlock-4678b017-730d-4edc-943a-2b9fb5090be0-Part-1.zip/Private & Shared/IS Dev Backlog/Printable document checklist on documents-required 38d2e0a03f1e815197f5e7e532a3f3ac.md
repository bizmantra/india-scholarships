# Printable document checklist on /documents-required subpages

Impact: Medium
Status: Deferred
Description: Context / Why it matters:
Serves the Rajesh Uncle persona — parent, limited tech comfort, wants physical verification before sending child to apply.

Plan / What to do:
Add 'Download Printable Checklist' button on every /documents-required subpage. window.print() + print-optimised CSS class, or simple PDF of docs_needed array. High-contrast, clean layout.

Trigger:
Helpline subpage done first
ID: IS-5