# West Bengal deep coverage (Nabanna, SVMCM, Aikyashree)

Impact: Medium
Status: ✅ Done
Description: Context / Why it matters:
WB has 6,034 impressions currently but demand is growing. Nabanna + SVMCM are both high-search scholarships.

Plan / What to do:
Research all WB state scholarships using the Odisha methodology. Build full 29-field records for Nabanna, SVMCM, Aikyashree, Ektashree, Oasis. Treat WB as the second state vertical after Odisha.

Trigger:
After Odisha model proven at scale
ID: IS-12