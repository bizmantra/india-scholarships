# Optimize Similar Opportunities relevance algorithm

Impact: Medium
Status: Backlog
Description: Context / Why it matters:
The similar opportunities recommendation grid at the bottom of scholarship detail templates is currently using a very basic fallback chain. Optimizing this increases user session depth and GSC click-throughs.

Plan / What to do:
Update the query logic in Next.js to match and sort similar opportunities prioritizing:
1. Same State (e.g. WB student sees WB scholarships)
2. Same Stream (e.g. Engineering student sees engineering)
3. Same Education Level.
ID: IS-34
Type: Analysis, Content Task