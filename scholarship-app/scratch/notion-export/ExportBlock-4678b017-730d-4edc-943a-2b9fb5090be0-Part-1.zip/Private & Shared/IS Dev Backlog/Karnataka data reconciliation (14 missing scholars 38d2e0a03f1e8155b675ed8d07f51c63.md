# Karnataka data reconciliation (14 missing scholarships)

Impact: Medium
Status: ✅ Done
Description: Context / Why it matters:
Karnataka has 12,470 impressions of state-level demand but partial coverage.

Plan / What to do:
14 Karnataka scholarships were researched but are not in the main CSV/database. Reconcile Karnataka_high_level_research.md data into main Google Sheet. Note: Karnataka has 12-department structure, more complex than Odisha.

Trigger:
After NOW + NEXT complete
ID: IS-7