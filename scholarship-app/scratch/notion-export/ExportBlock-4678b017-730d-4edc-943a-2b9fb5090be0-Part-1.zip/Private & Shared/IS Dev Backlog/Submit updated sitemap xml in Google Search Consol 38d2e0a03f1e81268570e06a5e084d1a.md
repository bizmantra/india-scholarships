# Submit updated sitemap.xml in Google Search Console

Impact: Critical
Status: ✅ Done
Description: Context / Why it matters:
700 subpages are live but Google won't discover them efficiently without sitemap submission. Every day without this is indexing delay.

Plan / What to do:
GSC → Sitemaps → submit https://www.indiascholarships.in/sitemap.xml. This triggers efficient crawl of the 700 new subpages generated in the Antigravity sprint.
ID: IS-2