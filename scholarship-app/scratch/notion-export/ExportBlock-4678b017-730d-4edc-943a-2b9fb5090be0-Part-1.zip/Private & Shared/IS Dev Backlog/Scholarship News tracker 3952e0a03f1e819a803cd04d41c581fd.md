# Scholarship News tracker

Impact: High
Status: Cancelled
Description: Whenever a scholarship
• 
opens

• 
closes

• 
extends deadline

• 
changes eligibility

• 
increases amount

we update the page immediately.

Trigger:
Chatgpt
ID: IS-61
Type: Strategy