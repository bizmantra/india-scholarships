# Integrate Google Keyword Planner API for keyword research

Impact: Low
Status: In Progress
Description: Set up Google Ads API connection and integrate Google Keyword Planner for automated or script-based keyword research on scholarships. Includes obtaining a Manager Account, developer token, client ID, client secret, and generating a refresh token to perform queries.
ID: IS-50

# From Antrigravity

Walkthrough: Google Ads API Integration for Keyword Planner

We have successfully integrated the Google Ads API into the workspace, authenticated it with your Google credentials, and prepared the script to fetch search volume and keyword suggestions.

---

## 🛠️ What Was Done

1. **Authentication Configuration:**
    - Configured [google-ads.yaml](file:///Users/roshankumar/Desktop/Schlarship%20Tracker%20/Scholarship-Tracker-POC-antigravity/scholarship-app/google-ads.yaml) in the project root containing your Developer Token, OAuth Client credentials, and Refresh Token.
    - Updated [.gitignore](file:///Users/roshankumar/Desktop/Schlarship%20Tracker%20/Scholarship-Tracker-POC-antigravity/scholarship-app/.gitignore) to ensure credentials and virtual environments are never committed.
2. **Environment & Script Setup:**
    - Created a Python virtual environment `/venv` and installed the `google-ads` and `reportlab` packages.
    - Created [scripts/keyword-research.py](file:///Users/roshankumar/Desktop/Schlarship%20Tracker%20/Scholarship-Tracker-POC-antigravity/scholarship-app/scripts/keyword-research.py) to handle keyword queries, filter for the India geographic region, and export results directly to a CSV report.
    - Generated a professional [google_ads_api_design_document.pdf](file:///Users/roshankumar/Desktop/Schlarship%20Tracker%20/Scholarship-Tracker-POC-antigravity/scholarship-app/google_ads_api_design_document.pdf) for the Google API compliance team.
3. **API Application Filed:**
    - Completed the Basic Access token application.

---

## 🚀 How to Run the Keyword Planner

Once Google Ads API Basic Access is approved, execute the following command in your terminal from the `scholarship-app` directory:

```bash
./venv/bin/python scripts/keyword-research.py -c 9274144850 -k "scholarships, study in india, scholarships for girls"
```

### Parameters:

- `c` : Your 10-digit Google Ads Customer ID (without hyphens).
- `k` : Comma-separated list of seed keywords you want suggestions/volumes for.

### Output:

The report will be exported to:
📂 **[Keyword research/keyword_ideas_report.csv](file:///Users/roshankumar/Desktop/Schlarship%20Tracker%20/Scholarship-Tracker-POC-antigravity/scholarship-app/Keyword%20research/keyword_ideas_report.csv)**

It will include:

1. Keyword variations.
2. Average monthly search volume.
3. Competition level (`HIGH`, `MEDIUM`, `LOW`).
4. Low range top-of-page bid (INR).
5. High range top-of-page bid (INR).