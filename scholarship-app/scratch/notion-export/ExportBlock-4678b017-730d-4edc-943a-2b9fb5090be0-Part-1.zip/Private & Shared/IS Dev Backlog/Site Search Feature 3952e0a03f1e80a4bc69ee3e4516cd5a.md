# Site Search Feature

Impact: Critical
Status: ✅ Done
Description: Need to implement a dynamic search for the website. Currently doesnt have any search capability. What are the best ways to deploy a search so information is quick and accurate to find 
ID: IS-48
Type: Feature