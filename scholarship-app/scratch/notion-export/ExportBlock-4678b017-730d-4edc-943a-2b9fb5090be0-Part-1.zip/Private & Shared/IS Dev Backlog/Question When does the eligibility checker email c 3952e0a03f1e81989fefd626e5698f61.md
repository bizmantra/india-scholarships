# Question: When does the eligibility checker email capture go live?

Impact: High
Status: Backlog
Description: Context / Why it matters:
At current traffic, 0.5% conversion = 500 segmented subscribers/month. This is the future monetisation foundation and should come before WhatsApp.
ID: IS-18