# BITSAT page — reframe as Scholarships for BITSAT Qualifiers

Impact: Medium
Status: Cancelled
Description: Context / Why it matters:
240K impressions at 0.59% CTR — content mismatch. Even 2% CTR = +3,400 clicks/month.

Plan / What to do:
BITSAT is an entrance exam not a scholarship. Reframe page title and intro as 'Scholarships for BITSAT Qualifiers / BITS Pilani Students'. Add actual scholarship schemes available to BITS students. Update slug if needed.

Trigger:
Review after enrichment batch
ID: IS-8