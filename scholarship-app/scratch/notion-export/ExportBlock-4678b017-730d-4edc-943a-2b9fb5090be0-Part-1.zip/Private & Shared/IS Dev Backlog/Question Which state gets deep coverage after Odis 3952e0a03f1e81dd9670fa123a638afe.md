# Question: Which state gets deep coverage after Odisha?

Impact: High
Status: ✅ Done
Description: West Bengal (Nabanna + SVMCM demand) vs MP (MMVY dominant) vs Punjab (third highest impressions at 12,871). Use Odisha methodology.

Context / Why it matters:
West Bengal (Nabanna + SVMCM demand) vs MP (MMVY dominant) vs Punjab (third highest impressions at 12,871). Use Odisha methodology.
ID: IS-19