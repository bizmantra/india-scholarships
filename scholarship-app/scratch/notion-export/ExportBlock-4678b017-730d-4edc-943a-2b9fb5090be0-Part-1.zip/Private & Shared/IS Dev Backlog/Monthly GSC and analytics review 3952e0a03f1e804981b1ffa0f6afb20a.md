# Monthly GSC and analytics review

Status: Backlog
ID: IS-30