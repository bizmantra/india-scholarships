# Competitor tracker

Impact: High
Status: Backlog
Description: Every month I'll tell you"Competitor X just added 14 new scholarships."
or"Buddy4Study has created a calculator."
or"Careers360 added scholarship filters."
This helps us stay ahead rather than react.

Trigger:
chatgpt
ID: IS-24