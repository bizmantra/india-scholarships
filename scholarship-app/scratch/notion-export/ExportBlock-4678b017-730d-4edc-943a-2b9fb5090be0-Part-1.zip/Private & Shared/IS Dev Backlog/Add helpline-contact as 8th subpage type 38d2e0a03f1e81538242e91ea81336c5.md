# Add /helpline-contact as 8th subpage type

Impact: High
Status: Cancelled
Description: Context / Why it matters:
Queries like 'how to contact e-Kalyan' and 'Sitaram Jindal helpline number' are uncompetitive. Zero manual effort — data already in database.

Plan / What to do:
Claude Code prompt: In app/scholarships/[slug]/[subpage]/page.tsx, add 'helpline-contact' as the 8th subpage key. Render the helpline field with contact details, official email, and link. Add to sitemap.ts. ~165 scholarships have helpline data populated.
ID: IS-6