# Email capture on eligibility checker results screen

Impact: High
Status: Backlog
Description: Context / Why it matters:
At 100K+ monthly visitors, 0.5% conversion = 500 segmented subscribers/month. Future monetisation foundation.

Plan / What to do:
After checker returns eligible scholarships, show inline email field: 'Get notified when applications open for your matched scholarships.' POST to /api/subscribe. Pre-populate hidden fields with state, caste, level, income from checker inputs.

Trigger:
NOW tasks complete
ID: IS-4