# Feature: Lead Gen Email Capture

Impact: Critical
Status: Backlog
Description: WhatsApp has higher open rates for Priya/Rajesh Uncle personas but needs Business API approval (weeks). Email is immediate. Decision: email first, then WhatsApp in Month 2.

Context / Why it matters:
WhatsApp has higher open rates for Priya/Rajesh Uncle personas but needs Business API approval (weeks). Email is immediate. Decision: email first, then WhatsApp in Month 2.
ID: IS-20

Check IS-18 task also