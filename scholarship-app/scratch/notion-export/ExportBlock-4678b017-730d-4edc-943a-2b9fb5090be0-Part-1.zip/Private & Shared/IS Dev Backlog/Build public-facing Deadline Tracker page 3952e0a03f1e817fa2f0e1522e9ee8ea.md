# Build public-facing Deadline Tracker page

Impact: High
Status: ✅ Done
Description: Context / Why it matters:
High search volume for upcoming scholarship deadlines. Provides students with a single, consolidated timeline of closing dates.

Plan / What to do:
Create a new route /scholarships/deadlines. Fetch active scholarships sorted chronologically by deadline. Render a clean table/timeline showing scholarship titles, closing dates, days remaining counters, and quick filter options.
ID: IS-33
Type: Feature, Strategy