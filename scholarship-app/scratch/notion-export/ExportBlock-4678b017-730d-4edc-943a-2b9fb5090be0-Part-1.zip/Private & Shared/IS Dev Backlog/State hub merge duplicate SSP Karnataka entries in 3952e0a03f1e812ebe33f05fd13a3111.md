# State hub: merge duplicate SSP Karnataka entries into one canonical card

Impact: Low
Status: ✅ Done
Description: Found in IS-37 QA. 'SSP Pre-Matric & Post-Matric Scholarship (Karnataka)' (id: ssp-pre-matric-post-matric-scholarship-karnataka, enriched, deadline 2026-01-15) and 'Pre-Matric & Post-Matric Scholarships (SSP)' (id: pre-matric-post-matric-scholarships-ssp, thin entry, deadline 'Not specified') appear to be the same underlying scheme listed twice. Merge into one canonical entry and redirect the duplicate slug. DB editorial decision required before code change.
ID: IS-43
Type: Content Task, Feature