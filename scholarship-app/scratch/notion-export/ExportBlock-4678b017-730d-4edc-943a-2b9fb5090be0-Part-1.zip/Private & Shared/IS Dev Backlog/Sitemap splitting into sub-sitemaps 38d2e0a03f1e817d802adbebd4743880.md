# Sitemap splitting into sub-sitemaps

Impact: Low
Status: Deferred
Description: Context / Why it matters:
Next.js limit is 50,000 URLs per sitemap. Currently well under. Set reminder at 40,000.

Plan / What to do:
Refactor app/sitemap.ts to export a sitemap index file referencing split sitemaps: /sitemap-states.xml, /sitemap-subpages-1.xml, /sitemap-subpages-2.xml. Currently at ~1,800 URLs — not needed yet.

Trigger:
Only when total URLs approach 40,000
ID: IS-10