# WhatsApp alert subscription (MSG91/Twilio)

Impact: High
Status: Backlog
Description: Context / Why it matters:
Priya and Rajesh Uncle live on WhatsApp not email. Higher open rates. But API approval takes time — do email first.

Plan / What to do:
Integrate MSG91 (better for India) WhatsApp Business API. Capture verified phone numbers alongside email. Send deadline alerts: 'The PM Yashasvi deadline closes in 48 hours. Apply here.' Needs WhatsApp Business API approval first.

Trigger:
After email capture proven · Month 2
ID: IS-16