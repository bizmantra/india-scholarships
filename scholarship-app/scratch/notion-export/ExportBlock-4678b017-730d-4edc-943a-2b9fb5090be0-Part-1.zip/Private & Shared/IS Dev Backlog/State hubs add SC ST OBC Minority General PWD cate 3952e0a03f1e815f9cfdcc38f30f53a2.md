# State hubs: add SC/ST/OBC/Minority/General/PWD category filter chips

Impact: Medium
Status: ✅ Done
Description: Found in IS-37 QA. State hub pages (e.g. /scholarships-in/karnataka) show a flat list of 26 cards with no way to filter by SC/ST/OBC/Minority/General/PWD. 82% of traffic is mobile. Add category filter chips above the scholarship list so users can drill down without scrolling the full list. Affects all state hub pages.
ID: IS-44
Type: Content Task, Feature