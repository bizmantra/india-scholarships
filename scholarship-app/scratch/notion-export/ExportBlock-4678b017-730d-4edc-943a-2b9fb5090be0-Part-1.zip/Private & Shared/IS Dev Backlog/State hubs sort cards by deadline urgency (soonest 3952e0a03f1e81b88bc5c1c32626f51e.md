# State hubs: sort cards by deadline urgency (soonest open first, expired last)

Impact: Medium
Status: ✅ Done
Description: Found in IS-37 QA. State hub card order is arbitrary. Sort cards by: (1) deadline urgency — soonest non-expired first, (2) expired/no-deadline pushed to bottom. Secondary: highest amount_annual. This helps mobile users identify the most time-sensitive opportunities immediately. Also applies to the main /scholarships listing. Consider making sort user-selectable (deadline / amount / newest).
ID: IS-45
Type: Content Task, Feature