# Scholarship Tools Expansion — Phase 2 (Document Checklist, Merit Checker, Stipend vs Loan)

Impact: Medium
Status: Backlog
Description: Phase 2 expansion of the IndiaScholarships tool suite. Three tools identified for future consideration:

1. DOCUMENT CHECKLIST GENERATOR
Student enters their profile (category, scholarship type, education level) and gets a personalised list of documents they need to apply. High utility — most students lose applications due to missing paperwork. Data already exists in our DB via the documents_required field. Low effort, no external dependencies. Suggested slug: /tools/document-checklist-generator

2. MERIT / RANK CUTOFF CHECKER
Student enters their board/competitive exam rank or percentage and sees which merit-based scholarships they qualify for (e.g. Central Sector Scholarship, Inspire, state merit schemes). Good SEO angle — targets queries like 'JEE rank scholarship eligibility' and 'NEET score scholarship'. Medium effort — requires mapping rank/score thresholds to scholarship eligibility in the DB. Suggested slug: /tools/merit-rank-cutoff-checker

3. STIPEND VS LOAN CALCULATOR
Side-by-side comparison tool: 'Should I take this scholarship stipend or an education loan?' Shows the long-term financial difference including interest cost, repayment burden, and net benefit of the scholarship over time. Useful for higher education students choosing between scholarship + partial loan vs full loan. Medium effort. Suggested slug: /tools/stipend-vs-loan-calculator

All three should follow the existing tool template (problem statement, calculator, scenario examples, FAQ + JSON-LD schema) and be added to the Tools Hub with Coming Soon cards until implemented.
ID: IS-77
Type: Feature