# Feature: Twitter Distribution

Impact: Medium
Status: Backlog
Description: Distribute (auto-update Twitter) for traffic, distribution and branding 
ID: IS-80
Type: Feature