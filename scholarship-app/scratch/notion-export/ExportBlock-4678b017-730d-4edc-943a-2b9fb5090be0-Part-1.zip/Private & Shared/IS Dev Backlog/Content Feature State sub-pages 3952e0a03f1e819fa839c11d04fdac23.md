# Content Feature: State sub-pages

Impact: High
Status: ✅ Done
Description: Optimize Next.js route structures and titles for state hub subpages (e.g. /apply-online, /last-date, /eligibility) to capture localized high-intent search volumes (like UP Scholarship, Aikyashree WB, SSP Karnataka). Focus on dynamically resolving year titles and expanding sitemap inclusion.

Reference:
- Hub Routes: scholarship-app/app/scholarships/[slug]/page.tsx
- State Hub Config: scholarship-app/lib/db.ts -> getAllStates()
ID: IS-55
Type: Content Task, Feature