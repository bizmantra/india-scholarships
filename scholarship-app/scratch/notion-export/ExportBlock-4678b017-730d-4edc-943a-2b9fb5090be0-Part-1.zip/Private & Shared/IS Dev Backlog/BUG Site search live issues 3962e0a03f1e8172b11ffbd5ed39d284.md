# BUG: Site search live issues

Impact: High
Status: In Progress
Description: Setting journal_mode = WAL pragma on SQLite failed with SQLITE_CANTOPEN in the production environment (Vercel) due to Vercel's read-only serverless filesystem, returning 500 error for /api/search.
ID: IS-63
Type: Bug

# SQLite Read-Only Database Fallback Fix & Next.js Bundle Tracing

## Problem Description

When triggering the global Search (`Cmd+K` / `Ctrl+K`) or using the Search button in the Header, the live production site failed to load results, showing "No results found". 

Checking `/api/search` returned a **500 Internal Server Error** with the message `{"error":"Failed to fetch search index","details":"unable to open database file"}`.

### Root Cause

1. **Serverless Filesystem Constraints**: In serverless environments like Vercel, the runtime filesystem is strictly **read-only**.
2. **WAL Journaling Permission Denied**: Our SQLite database initialization function `getDatabase()` inside `lib/db.ts` executed `db.pragma('journal_mode = WAL')`. Write-Ahead Logging requires write permission in the database directory (`data/`) to create/write the `scholarships.db-wal` and `scholarships.db-shm` files. This threw a `SQLITE_CANTOPEN` error.
3. **Asset Bundling Issue (Output File Tracing)**: Additionally, because `better-sqlite3` is defined as a `serverExternalPackage` in `next.config.ts`, Next.js's static analysis did not trace and include `data/scholarships.db` into the Vercel serverless build output bundle for the dynamic `/api/search` route. At runtime, the database file simply did not exist inside the serverless container, resulting in `"unable to open database file"`.

## Solution & Implementation

We implemented a two-part fix to make search robust in production:

### 1. Read-Only Fallback

Modified `getDatabase()` inside `lib/db.ts` to catch filesystem initialization exceptions and fall back to opening the database file in `{ readonly: true }` mode for serverless environments.

### 2. Output File Tracing Config

Force Next.js to package the SQLite database file into Vercel's serverless function bundles:

- **Route Reference**: Added a runtime file system check (`fs.existsSync(dbFile)`) inside the `/api/search` GET route handler to force dependency tracing.
- **Next.js Config**: Configured `outputFileTracingIncludes` inside `next.config.ts` to explicitly map `data/scholarships.db` as a required file asset for API routes:

```tsx
outputFileTracingIncludes: {
  '/api/**/*': ['./data/scholarships.db'],
},
```

## Code Commits

- **Commit 1**: `fix(db): support readonly fallback mode for Vercel serverless environment (IS-48)`
- **Commit 2**: `fix(search): configure next.config.ts outputFileTracingIncludes and runtime file reference to force trace SQLite database into serverless function bundle`