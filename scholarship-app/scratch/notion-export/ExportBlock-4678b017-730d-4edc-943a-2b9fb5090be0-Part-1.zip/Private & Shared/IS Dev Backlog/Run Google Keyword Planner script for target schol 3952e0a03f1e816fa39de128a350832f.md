# Run Google Keyword Planner script for target scholarship keywords

Impact: Medium
Status: Backlog
Description: Develop and run a Python script using the google-ads SDK to query search volumes, competition rates, and bid estimates directly from Google Keyword Planner for key scholarship queries. Save results to CSV files.
ID: IS-51
Type: Analysis