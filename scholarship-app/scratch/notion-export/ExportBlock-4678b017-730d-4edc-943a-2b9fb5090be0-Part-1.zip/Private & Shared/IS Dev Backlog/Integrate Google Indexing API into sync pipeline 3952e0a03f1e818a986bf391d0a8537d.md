# Integrate Google Indexing API into sync pipeline

Impact: Medium
Status: Backlog
Description: Context / Why it matters:
Newly added or updated scholarships take weeks to be naturally crawled by Google. Google Indexing API allows requesting instant indexing for GovernmentService and JobPosting schema pages, which speeds up search presence (often indexed in <24 hours).

Plan / What to do:
Add Google Indexing API integration into scripts/sync-wordpress-api.js to send crawl/refresh requests automatically whenever a page is synced.
ID: IS-35