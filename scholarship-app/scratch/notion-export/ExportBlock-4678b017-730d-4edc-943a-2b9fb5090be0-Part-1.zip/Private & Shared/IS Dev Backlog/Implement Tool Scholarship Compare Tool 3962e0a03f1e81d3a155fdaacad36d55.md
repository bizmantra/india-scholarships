# Implement Tool: Scholarship Compare Tool

Impact: High
Status: Backlog
Description: Create a robust Scholarship Compare Tool offering a side-by-side eligibility and benefit matrix for selected opportunities.
ID: IS-73
Type: Feature