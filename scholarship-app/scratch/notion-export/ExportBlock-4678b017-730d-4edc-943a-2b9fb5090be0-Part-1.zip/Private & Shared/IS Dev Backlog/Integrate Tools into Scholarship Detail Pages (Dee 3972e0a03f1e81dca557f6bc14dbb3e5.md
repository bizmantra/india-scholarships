# Integrate Tools into Scholarship Detail Pages (Deep Links)

Impact: High
Status: Backlog
Description: GOAL: Drive tool usage and reduce friction on scholarship detail pages by surfacing relevant tools contextually — at the exact moment a student is reading eligibility criteria, income limits, or academic cutoffs.

CONTEXT: Right now tools (/tools) and scholarship detail pages (/scholarships/[slug]) are completely siloed. A student reading about a scholarship has to navigate away to use a calculator, which kills momentum.

APPROACH (Phase 1 — Deep Links, ship fast):
Add contextual tool CTAs directly on the detail page at relevant sections:
• Near 'Eligibility Criteria' → Scholarship Eligibility Checker CTA: 'Check if you qualify →'
• Near 'Income Limit' field → Family Income Calculator CTA: 'Verify your household income →'
• Near 'Minimum Marks / CGPA' field → CGPA to Percentage Converter CTA: 'Convert your CGPA →'
• Near 'Benefits / Amount' section → Scholarship Amount Calculator CTA: 'Estimate your benefit →'
• Bottom of page → 'Explore similar tools' strip (passive, links to /tools)

IMPLEMENTATION NOTES:
• Start with deep links only (buttons/cards that open the standalone tool page). No inline widgets yet.
• Links can be pre-parameterised if the tool supports URL params (e.g. pre-select category/level based on the scholarship record).
• Use conditional rendering: only show a tool CTA if the relevant DB field is populated (e.g. only show Income Calculator CTA if income_limit field is non-null).
• Target file: app/scholarships/[slug]/page.tsx and relevant subpage components.

PHASE 2 (future, separate ticket): Embed inline mini-widgets on the detail page so students never leave the page.

SUCCESS METRIC: Track clicks on tool CTAs from detail pages. Goal is >5% CTR from detail page to tool.
ID: IS-75
Type: Feature