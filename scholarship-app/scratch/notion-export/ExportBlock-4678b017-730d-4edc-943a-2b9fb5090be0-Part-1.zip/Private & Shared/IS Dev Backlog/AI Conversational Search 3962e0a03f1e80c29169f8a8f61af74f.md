# AI / Conversational Search

Impact: Medium
Status: Deferred
Description: Future feature request to be assesed. IS-48 already implemented a site search on 7th Jul 2026
ID: IS-62
Type: Feature

this from a ChatGPT conversation also: [https://chatgpt.com/share/6a4d39f6-966c-83ee-be8a-6fe6280d9787](https://chatgpt.com/share/6a4d39f6-966c-83ee-be8a-6fe6280d9787)

[https://chatgpt.com/share/6a4d39f6-966c-83ee-be8a-6fe6280d9787](https://chatgpt.com/share/6a4d39f6-966c-83ee-be8a-6fe6280d9787)