# Feature-Whatsapp alerts

Impact: Critical
Status: Backlog
Description: Send alerts via Whatsapp. For traffic and distribution
ID: IS-79
Type: Feature