# Feature: Telegram Alerts

Impact: Critical
Status: Backlog
Description: Build subscription alerts to Telegram. To increase traffic and distribiution
ID: IS-78
Type: Feature