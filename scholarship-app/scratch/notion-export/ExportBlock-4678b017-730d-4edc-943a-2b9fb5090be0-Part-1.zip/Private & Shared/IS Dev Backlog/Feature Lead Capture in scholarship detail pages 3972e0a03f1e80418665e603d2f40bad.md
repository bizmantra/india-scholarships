# Feature: Lead Capture in scholarship detail pages

Status: Backlog
ID: IS-82
Type: Feature

How can we capture leads from teh scholarship detail pages?
Needs discussion. 
Refer to past chats with Chatgpt and Claude

Right now we are leaking visitors out by either by direct bounce or by leading them away to the job site 
Can we integrate a step 
Can we send them by email?