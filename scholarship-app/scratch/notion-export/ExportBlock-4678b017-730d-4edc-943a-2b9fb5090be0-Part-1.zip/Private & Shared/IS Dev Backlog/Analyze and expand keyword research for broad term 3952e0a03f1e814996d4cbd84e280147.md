# Analyze and expand keyword research for broad term 'scholarships' (India)

Impact: High
Status: ✅ Done
Description: Conduct keyword research for the broad term 'scholarships' in the Indian market. Analyze user-provided Google Keyword Planner export data, combine it with programmatic/web search volume research, cluster by search intent, and identify high-value/low-competition keyword opportunities to expand content targeting.
ID: IS-52
Type: Analysis

## Analysis complete — July 6, 2026

Done against Roshan's own Google Keyword Planner export (1,890 keywords) + an Ubersuggest export scoped to UP/NSP (710 keywords), not estimated volumes.

## ⚠️ Methodology caveat, read first

Bare acronyms are inflated by unrelated searches. GKP shows the identical rounded volume (5,000,000/mo) for both "ssp" and "maha dbt" — but these are ambiguous short acronyms (SSP is also a police rank; Maha DBT covers many non-scholarship subsidy schemes). The moment "scholarship" qualifies the term, volume drops ~10x consistently ("ssp" 5M → "ssp scholarship" 500K; "maha dbt" 5M → "mahadbt scholarship" 500K). Every figure below uses the qualified, more defensible number.

## 🎯 Headline finding: "UP Scholarship" — ~4-5M/month, currently at 0 impressions

Two independent tools agree within 20% of each other: GKP ~5,000,000/mo, Ubersuggest ~4,090,000/mo for the core "up scholarship" query. Confirmed in an earlier session this week: **0 GSC impressions** for this term, and only **4 live UP scholarships**. For comparison, the entire site did ~61,733 clicks in June 2026 across every page combined. This single number makes the UP discovery sprint (already in the backlog) the highest-priority item found in this entire project — bigger than the 266→500 volume push, bigger than any individual CTR fix.

## Full cluster breakdown (qualified terms)

| Cluster | Volume/mo | Current status | Priority |
| --- | --- | --- | --- |
| UP Scholarship (core) | ~4-5M | 4 live, 0 impressions | Critical |
| NSP Scholarship + Scholarship NSP | ~1,220,000 | Confirmed weak: 14K impressions, 84 clicks | Critical |
| SSP Scholarship (Karnataka) | ~500-528K | Live but split across 2 likely-duplicate cards (already flagged separately in Backlog) | High |
| Post-Matric Scholarship (generic) | ~500K | Multiple state pages exist | High |
| Mahadbt Scholarship (Maharashtra) | ~500K | 12 MH scholarships live — check if MahaDBT itself has a dedicated page | High |
| Aikyashree (West Bengal) | ~500K-1M | Live, WB fully worked through per last week's audit | Verify ranking |
| SVMCM (West Bengal) | ~500K | Live but confirmed **worst CTR on the whole site** (0.04%) — now we know why that matters | Critical |
| e-Grantz (Kerala) | ~500-550K | Live, same abbreviation-buried title issue flagged earlier | High |
| Jnanabhumi (Andhra Pradesh) | ~500K | Not confirmed live under this name — check AP's 7 live scholarships | Check |
| e-Kalyan (Jharkhand) | ~50K | Live, already actioned in the CTR tracker | Already actioned |
| Vidyasaarathi (Central/Private) | ~50-100K | Not confirmed live — check | Check |
| Bare "scholarship(s)" | ~1.2M-5M | Extremely competitive (Buddy4Study/LeverageEdu/[NSP.gov.in](http://NSP.gov.in) territory) | Not realistically winnable head-on |

## NSP long-tail: 103 real questions, easy structured-content win

"why nsp scholarship is not received," "when nsp scholarship will be credited," "is nsp scholarship for general category," etc. — individually tiny (10-1,600/mo) but collectively real, and a direct fit for the FAQPage schema already implemented on the site. Recommend one comprehensive NSP FAQ section answering the top 20-30, not 103 separate pages.

## UP secondary intent layer (beyond the core term)

| Intent | Volume/mo | Content implication |
| --- | --- | --- |
| Status check | ~110-165K | "How to check your UP scholarship status" guide |
| Year-qualified | ~165K | Confirms the "include the year" title formula applies here too |
| Login | ~33K | Pure navigation intent, low competition |
| OTR (One Time Registration) | ~22K | UP-specific portal step — genuinely distinct guide opportunity |
| Deadline | ~22K | Matches the proven "last date" modifier pattern |
| Renewal | ~15-33K | Repeat-visitor intent |

## ⛔ Explicitly excluded: coaching-institute "scholarship tests"

"aakash scholarship exam" (8,100/mo), "allen scholarship test" (18,100/mo), "akash scholarship test" (9,900/mo) — real volume, but these are JEE/NEET coaching marketing funnels, not need-based aid. Different audience and positioning than the rest of the site. Deliberately excluded, not an oversight.

## Recommended next actions

1. Elevate the UP discovery sprint to top priority — biggest gap in the whole project
2. Merge the SSP Karnataka duplicate cards (real ~500K/mo demand being split)
3. Re-prioritize the SVMCM title fix — confirmed sitting on ~500K/mo, not a low-value term
4. Build the NSP FAQ section (103 questions, reuses existing schema)
5. Check Jnanabhumi (AP) and Vidyasaarathi coverage under different names
6. Do NOT chase the coaching-institute "scholarship test" cluster