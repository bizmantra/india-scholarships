# Run Gemini enrichment on 5 broken pages

Impact: Critical
Status: ✅ Done
Description: Context / Why it matters:
Combined 669K impressions at under 0.5% CTR. These pages are ranking but failing to convert. Content is clearly thin or stale.

Plan / What to do:
Run: node scripts/enrich-all-low-ctr-gemini.js --limit 5. Target pages: Jharkhand e-Kalyan (0.16% CTR), SVMCM WB (0.13%), MMVY MP (0.64%), Azim Premji (0.34%), e-Grantz Kerala (0.55%). Human-review Google Sheets output before WP sync.
ID: IS-3