# Run enrichment batch on 127 expired deadline records

Impact: Critical
Status: ✅ Done
Description: Context / Why it matters:
127 of 214 scholarships show 'Applications Closed'. Deadline validator works correctly — the data is stale. Fixing this protects brand trust.

Plan / What to do:
Run node scripts/enrich-all-low-ctr-gemini.js --limit 30 four times across the week. Check content-quality-report.md after each run to track progress. Human review before WP sync each time.

Trigger:
After Week 1 broken pages done
ID: IS-9