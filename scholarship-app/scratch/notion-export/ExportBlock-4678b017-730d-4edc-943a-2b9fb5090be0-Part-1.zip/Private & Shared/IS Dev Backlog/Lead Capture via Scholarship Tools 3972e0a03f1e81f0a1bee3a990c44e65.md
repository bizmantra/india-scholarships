# Lead Capture via Scholarship Tools

Impact: High
Status: Backlog
Description: GOAL: Capture student contact details at the highest-intent moment on the site — immediately after they complete a tool and see their results (e.g. Eligibility Checker shows 5 matching scholarships).

CONTEXT: Parked as of July 2026 until two decisions are made:
1. What do we offer the student in exchange for their contact? (the 'exchange value')
2. What infrastructure will send the follow-up? (email service, WhatsApp API, etc.)

OPTIONS TO DECIDE BETWEEN (for discussion when picking this up):
Option A — 'Email me my results': Zero-friction. Student enters email to receive their eligibility results or tool output. Requires: transactional email service (e.g. Resend, Mailchimp, SendGrid). Easiest to ship.
Option B — 'Get notified when applications open': Student opts in to deadline alerts for matched scholarships. Higher intent, higher value to student. Requires: email service + scheduled job to send alerts when scholarship status changes.
Option C — WhatsApp opt-in: 'Get alerts on WhatsApp'. Higher conversion rate in India. Requires: WhatsApp Business API setup (via Twilio, Interakt, or WATI). More complex setup.

WHERE TO INSERT THE FORM:
• End of Eligibility Checker results (highest intent — student just saw their matches)
• End of CGPA Converter results (after seeing their converted % + matched scholarships)
• End of Family Income Calculator results (after seeing income band + matched schemes)
• Scholarship detail page 'Alert me when this opens' CTA

PRE-REQUISITES BEFORE BUILDING:
• Decide on Option A / B / C above
• Set up chosen email/WhatsApp service and obtain API keys
• Decide on data storage: where leads are stored (a simple DB table, Airtable, Google Sheets, CRM)
• Define the first follow-up sequence (what does the student receive after opt-in?)

NOTE: Do NOT add a generic popup or modal. The opt-in must feel like a natural next step after the tool gives them value.
ID: IS-76
Type: Feature, Strategy