# Keyword research analysis

Impact: High
Status: In Discussion
Description: Analyse keywords from Google keyword planner and Ubersuggest and come up with a plan to execute them
ID: IS-59
Type: Analysis