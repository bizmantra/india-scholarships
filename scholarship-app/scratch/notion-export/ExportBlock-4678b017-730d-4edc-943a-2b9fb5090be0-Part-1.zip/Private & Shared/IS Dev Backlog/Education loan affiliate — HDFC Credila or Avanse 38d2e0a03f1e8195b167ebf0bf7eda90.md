# Education loan affiliate — HDFC Credila or Avanse

Impact: High
Status: Backlog
Description: Context / Why it matters:
High-intent placement — students who need more than scholarship covers are warm leads for education loans.

Plan / What to do:
Partner with HDFC Credila or Avanse (pay ₹2,000–5,000 per qualified lead). Place native widget on /scholarships-by-course/engineering and /medical pages. Trigger: student matches scholarship covering only partial tuition.

Trigger:
After 80K clicks/month · Month 3
ID: IS-14