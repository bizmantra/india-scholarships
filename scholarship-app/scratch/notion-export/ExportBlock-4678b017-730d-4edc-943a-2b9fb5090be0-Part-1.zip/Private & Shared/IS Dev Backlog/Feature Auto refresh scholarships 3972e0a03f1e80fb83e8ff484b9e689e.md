# Feature: Auto refresh scholarships

Status: Backlog
Description: How do we enable automatic verification (for internal use) and how do we keep the page fresh. Can users subscirbe to alerts and changes on this page?
ID: IS-83
Type: Feature

How can a user be notified of alerts and changes on a scholarship page?
What is important for them? 
Can tie-in to the overall lead gen strategy 

**This can also be used to internally verify and enrich scholarships**