# CTR Improvement: title/meta rewrites across 129 opportunity pages (~85K upside clicks/mo)

Impact: Critical
Status: Backlog
ID: IS-36
Type: Analysis

## Source

Built from the GSC export (indiascholarships_in-Performance-on-Search-2026-07-06, Jan–Jul 2026), analyzed via Claude.

## The number

129 pages have impressions well above what their CTR would predict for their ranking position. Total upside if each hit a realistic CTR for its position: **~85,000 extra clicks/month** — more than the site's entire June total. Calculated per-page: upside = (impressions × realistic target CTR for that position band) − current clicks. Target CTRs came from the site's own position-vs-CTR curve (pos 3-5 → 3%, 5-7 → 2.4%, 7-10 → 1.87%).

## Priority tiers

| Tier | Impressions | # pages | Upside |
| --- | --- | --- | --- |
| 1 | >100K | 10 | ~39,550 |
| 2 | 20K–100K | 28 | ~30,900 |
| 3 | 5K–20K | 22 | ~14,900 |

Suggested pacing: treat each tier as ONE backlog task (batch the copy edits in one sitting), not one task per page — fits the 5-task WIP limit.

## Tier 1 — do first (biggest absolute opportunity)

| Page | Clicks | Impr. | CTR | Pos. | Upside | Note |
| --- | --- | --- | --- | --- | --- | --- |
| bitsat-scholarship | 1,430 | 245,818 | 0.58% | 3.71 | +5,945 | Ranks BETTER than PM Yashasvi but converts 7x worse — likely title/snippet issue, not ranking |
| mmvy (Mukhyamantri Medhavi Vidyarthi Yojana) | 2,070 | 333,263 | 0.62% | 5.37 | +5,928 | VERIFIED: title buries "MMVY" after the long name. Lead with MMVY. |
| tata-capital-pankh-scholarship | 8,057 | 556,034 | 1.45% | 5.32 | +5,288 | VERIFIED: title says ₹12,000, page body says ₹1,00,000/year — fix the mismatch |
| jharkhand-e-kalyan-post-matric-scholarship | 340 | 157,655 | 0.22% | 4.71 | +4,390 | VERIFIED: same issue as MMVY, worst CTR-vs-position gap on the site |
| scholarships-in/odisha (state hub) | 1,690 | 228,037 | 0.74% | 6.24 | +3,783 |  |
| e-grantz-kerala-scstoecobc-support | 883 | 163,371 | 0.54% | 6.17 | +3,038 | Likely same abbreviation-buried pattern |
| nabanna-scholarship-west-bengal | 3,837 | 226,452 | 1.69% | 4.73 | +2,957 |  |
| hdfc-bank-parivartan-ecss-scholarship | 3,161 | 253,656 | 1.25% | 6.14 | +2,927 |  |
| azim-premji-scholarship | 472 | 132,027 | 0.36% | 6.04 | +2,697 |  |
| svmcm (Swami Vivekananda Merit-cum-Means) | 154 | 114,823 | 0.13% | 6.82 | +2,602 | Lowest CTR on the entire site |

(Tier 2 and 3 — 50 more pages — tracked in the interactive Claude artifact from this session; ping Claude to regenerate the full list if needed.)

## The proven title formula

`[Abbreviation if one exists] + Scheme Name + [Year] : [Amount] | Apply Online, Eligibility & Last Date`

- Lead with the abbreviation when it's the dominant search term (MMVY, SVMCM, e-Kalyan) — burying it after the long official name is the #1 cause of the worst performers above
- Include the year — "2026" queries convert at 5-6% vs 1.78% site average
- Include "Apply Online" + "Last Date" — both show 2-3x lift wherever present
- State the amount consistently between title and page body

## How to measure

Re-export the same GSC report ~3-4 weeks after a batch of edits (Google needs to re-crawl). Compare CTR for the specific pages fixed, not the site-wide average.