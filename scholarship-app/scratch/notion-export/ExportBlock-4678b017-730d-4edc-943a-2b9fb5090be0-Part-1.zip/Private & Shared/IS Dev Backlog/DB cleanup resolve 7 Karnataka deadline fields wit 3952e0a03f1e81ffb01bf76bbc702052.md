# DB cleanup: resolve 7 Karnataka deadline fields with leaked research notes to clean ISO dates

Impact: Medium
Status: Backlog
Description: Found in IS-37 QA. 7 rows in the scholarships DB have raw editorial research notes stored in the deadline field (e.g. 'September 30, 2025 (tentative - some sources indicate November 30, 2025). VERIFY on official NSP...'). IDs: 23, 24, 27, 28, 29, 30, 31 (all Karnataka). IS-37 fixes the display layer, but the underlying DB values should be resolved to clean ISO dates or 'Not specified' via the enrichment pipeline. Run targeted enrichment on these 7 rows against NSP/SSP portals.
ID: IS-47
Type: Bug