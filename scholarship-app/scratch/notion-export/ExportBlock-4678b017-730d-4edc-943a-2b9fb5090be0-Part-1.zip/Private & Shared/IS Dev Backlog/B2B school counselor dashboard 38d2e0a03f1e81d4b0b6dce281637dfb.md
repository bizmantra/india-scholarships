# B2B school counselor dashboard

Impact: High
Status: Deferred
Description: Context / Why it matters:
Mrs. Sharma persona — power user managing hundreds of students. High-value B2B segment.

Plan / What to do:
Allow school counselors to upload student Excel sheet and export PDF eligibility matrix. Charge premium subscription. Need email list of 500+ school counselors first to validate demand before building.

Trigger:
Month 4-5 · needs email list of counselors first
ID: IS-17