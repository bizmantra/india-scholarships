# Rewrite Odisha + West Bengal hub page content in WordPress

Impact: High
Status: Cancelled
Description: Context / Why it matters:
Odisha hub has 207K impressions at 0.71% CTR. Title overrides deployed — now the content needs to match what students expect to find.

Plan / What to do:
Odisha hub: update intro paragraph to list top 4 schemes by name with amounts. WB hub: feature Nabanna, SVMCM, Aikyashree with eligibility summaries. Add quick eligibility filter links pre-set for each state.

Trigger:
Title overrides already deployed in code
ID: IS-11