# Feature: Monetization strategies

Impact: Critical
Status: Backlog
Description: How do we go beyond adsense?
ID: IS-81
Type: Feature

Affliliate programs?
Lead capture?
Ezoic / Mediavine follow-up

Others?

Need detailed strategy and planning - check either Claude or ChatGPT for past conversations