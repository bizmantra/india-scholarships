# Apply to Ezoic for premium ad monetisation

Impact: High
Status: Backlog
Description: Context / Why it matters:
At current traffic, ₹8,000–15,000/month potential. Better than plain AdSense — dynamic ad density optimisation protects mobile performance. ads.txt already exists in codebase.

Plan / What to do:
Go to ezoic.com and apply. No traffic minimum. Takes 15 minutes. Configure with strict Core Web Vitals protection — don't let ad scripts slow mobile load times.
ID: IS-15